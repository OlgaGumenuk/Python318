from django.shortcuts import render

def new_maiking(request):
    return render(request, 'new_maiking/new_maiking.html')