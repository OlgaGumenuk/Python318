from django.contrib import admin
from .models import New_maiking

admin.site.register(New_maiking)