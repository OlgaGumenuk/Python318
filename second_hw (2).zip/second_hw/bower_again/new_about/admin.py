from django.contrib import admin
from .models import New_about

admin.site.register(New_about)
