CREATE TABLE IF NOT EXISTS pricesmenu(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    catalog_course TEXT NOT NULL,
    add_course TEXT NOT NULL,
    information TEXT NOT NULL
);

